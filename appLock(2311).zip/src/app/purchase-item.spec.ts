import { PurchaseItem } from './purchase-item';

describe('PurchaseItem', () => {
  it('should create an instance', () => {
    expect(new PurchaseItem()).toBeTruthy();
  });
});
