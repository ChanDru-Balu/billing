export class Sales {
        id?: string;
        sellDate: string;
        invoice: string;
        total: number;
        discount: number;
        grandTotal: number;
        customerAddress1: string;
        customerId:string;
        customerMobile: string;
        customerName: string;
        items: string;
}
