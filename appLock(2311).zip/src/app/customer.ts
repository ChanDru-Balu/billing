export class Customer {
        id?: string;
        customerName: string;
        mobile: number;
        address1: string;  
        disabled: boolean; 
}
