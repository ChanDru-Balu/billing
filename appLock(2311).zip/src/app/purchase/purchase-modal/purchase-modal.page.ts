import { Component, Input, OnInit } from '@angular/core';
import { ModalController, ToastController } from '@ionic/angular';
import { DbService } from 'src/app/db.service';
import { Product } from 'src/app/product';
import { Purchase } from 'src/app/purchase';
import { Seller } from '../../seller';

@Component({
  selector: 'app-purchase-modal',
  templateUrl: './purchase-modal.page.html',
  styleUrls: ['./purchase-modal.page.scss'],
})
export class PurchaseModalPage implements OnInit {

  @Input() type: string;
  @Input() purchaseExist: any;

  sellers: Seller[];
  seller: any;
  invoice: any;
  product: {
    productName: string,
    price: string,
    qunatity: string,
    total: string
  };
  items: any = [];
  products: Product[];
  prodIndex: any;
  total: number;
  discount: number = 0;
  grandTotal: number;
  date: any;
  invoice_details: any = {};
  purchase: any;
  purchases: any;

  constructor(
    private modalController: ModalController,
    private dbService: DbService,
    private toast: ToastController,
    private dbservice: DbService
  ) { }

  ngOnInit() {

    // this.sellers = [
    //   {
    //     id: '23213dsda3321',
    //     sellerName: 'chandru',
    //     mobile: '8526868928',
    //     gst: '12asas313123123asdasdb',
    //     address1: 'address1',
    //   },
    //   {
    //     id: '23213dsda3322',
    //     sellerName: 'chan',
    //     mobile: '9385891608',
    //     gst: '12asas313123123asdasda',
    //     address1: 'address1',
    //   }
    // ]
    // this.products = [
    //   {
    //     id: '212',
    //     categoryName: 'category One',
    //     price: 1000,
    //     gst: 12,
    //     productName: 'Product One',
    //     quantity: 1
    //   },
    //   {
    //     id: '213',
    //     categoryName: 'category Two',
    //     price: 2000,
    //     gst: 12,
    //     productName: 'Product Two',
    //     quantity: 1
    //   }
    // ]
    this.dbService.dbState().subscribe((res) => {
      if (res) {
        this.dbService.fetchProducts().subscribe(async (products: Product[]) => {
          this.products = products;
        });
      }
    });
    this.dbService.dbState().subscribe((res) => {
      if (res) {
        this.dbService.fetchSellers().subscribe(async (sellers: Seller[]) => {
          this.sellers = sellers;
        });
      }
    });

    // this.addItem();
    if (this.type == 'edit') {
      // alert(this.dbService.purchaseObj['purchaseDate']);
      let obj = {};
      obj = this.dbService.purchaseObj;
      this.date = obj['purchaseDate'];
      this.invoice = obj['invoice'];
      this.total = obj['total'];
      this.discount = obj['discount'];
      this.grandTotal = obj['grandTotal'];
      this.items = JSON.parse(obj['items']);

      let seller = this.sellers.find(o => o.id === obj['sellerId']);
      this.seller = seller;

    }
  }

  addItem() {

    let product = {
      productName: '',
      price: 0,
      quantity: 0,
      total: 0
    }
    this.items.push(product);
  }

  dismiss() {
    console.log("Dismissed!");
    alert("Dismiss!");
    
    this.modalController.dismiss();
  }

  productSelect(event: any, i, product) {

    this.items[i]['productName'] = this.products[event.detail.value].productName;
    let gst = (this.products[event.detail.value].gst * 0.01 * this.products[event.detail.value].price);
    this.items[i]['price'] = this.products[event.detail.value].price + gst;
    this.items[i]['total'] = (this.products[event.detail.value].price + gst) * this.items[i].quantity;

    this.calculateTotal();
  }

  itemInput(e: any, i) {
    let baseCount = 0;
    this.items[i]['quantity'] = e.detail.value;
    this.items[i]['total'] = this.items[i]['price'] * e.detail.value;
    this.calculateTotal();

    this.dbService.getProductCount(this.items[i].productName)
    .then((res)=>{
      baseCount = res['quantity'];
      // if(baseCount < e.detail.value){
      //   alert("Please Just add only given values! Use Less then ,"+ baseCount);
      //   e.detail.value = baseCount;
      // }
    })
    .catch((error)=>{
      JSON.stringify(error);
    });
  }

  calculateTotal() {
    this.total = 0;
    for (let i = 0; i < this.items.length; i++) {
      this.total = this.total + this.items[i]['total'];
    }
  }

  discountInput(event: any) {
    this.grandTotal = this.total - this.discount;
  }

  submit() {

    if (this.type == 'edit') {
      let obj = {};

      obj['id'] = this.dbService.purchaseObj['id'];
      obj['purchaseDate'] = this.date;
      obj['invoice'] = this.invoice;
      obj['total'] = this.total;
      obj['discount'] = this.discount;
      obj['grandTotal'] = this.grandTotal;
      obj['sellerAddress1'] = this.seller['address1'];
      obj['sellerGst'] = this.seller['gst'];
      obj['sellerId'] = this.seller['id'];
      obj['sellerMobile'] = this.seller['mobile'];
      obj['sellerName'] = this.seller['sellerName'];

      this.editPurchase(obj);
    } else {

      let obj = {};

      obj['purchaseDate'] = this.date;
      obj['invoice'] = this.invoice;
      obj['total'] = this.total;
      obj['discount'] = this.discount;
      obj['grandTotal'] = this.grandTotal;
      obj['sellerAddress1'] = this.seller['address1'];
      obj['sellerGst'] = this.seller['gst'];
      obj['sellerId'] = this.seller['id'];
      obj['sellerMobile'] = this.seller['mobile'];
      obj['sellerName'] = this.seller['sellerName'];

      this.addPurchase(obj);

    }



    // this.modalController.dismiss({
    //   details: this.invoice_details
    // });

  }

  editPurchase(purchase) {
    this.dbService
      .updatePurchase(purchase, JSON.stringify(this.items))
      .then(
        (res) => {
          this.modalController.dismiss({
            status: true
          });
          this.getAllPurchases();
        },
        async () => {
          const toast = await this.toast.create({
            duration: 2500,
            message: 'Failed to add Product',
          });
          toast.present();
        }
      );
  }

  addPurchase(purchase) {
    this.dbService
      .addPurchase(purchase, JSON.stringify(this.items))
      .then(
        (res) => {
          this.modalController.dismiss({
            status: true
          });
          // this.getAllPurchases();
        },
        async () => {
          const toast = await this.toast.create({
            duration: 2500,
            message: 'Failed to add Product',
          });
          toast.present();
        }
      );
  }

  getAllPurchases() {
    this.dbservice.getAllPurchases().then((res) => {  this.purchases = res['data'] }).catch((error) => { alert(JSON.stringify(error)) });
  }

}

