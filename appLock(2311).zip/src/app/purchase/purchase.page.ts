import { Component, OnInit } from '@angular/core';
import { ModalController, NavController, ToastController } from '@ionic/angular';
import { DbService } from '../db.service';
import { Purchase } from '../purchase';
import { Seller } from '../seller';
import { InvoicePage } from './invoice/invoice.page';
import { PurchaseModalPage } from './purchase-modal/purchase-modal.page';

@Component({
  selector: 'app-purchase',
  templateUrl: './purchase.page.html',
  styleUrls: ['./purchase.page.scss'],
})
export class PurchasePage implements OnInit {

  sellers: Seller[];
  seller: any;
  invoice: any;
  purchases: Purchase[];

  constructor(
    private modalController: ModalController,
    private dbService: DbService,
    private toast: ToastController,
    private navCtrl: NavController
  ) { }

  ngOnInit() {
    this.getAllPurchases();

    this.sellers = [
      {
        id: '23213dsda3321',
        sellerName: 'chandru',
        mobile: '8526868928',
        gst: '12asas313123123asdasdb',
        address1: 'address1',
        disabled: true
      },
      {
        id: '23213dsda3322',
        sellerName: 'chan',
        mobile: '9385891608',
        gst: '12asas313123123asdasda',
        address1: 'address1',
        disabled: true

      }
    ]

    this.purchases = [
     {
      discount: 445.5,
      grandTotal: 1000,
      id: "1Gu2cicDK82",
      invoice: "0001",
      items: "[{\"productName\":\"Rice\",\"price\":57.82,\"quantity\":\"25\",\"total\":1445.5},{\"productName\":\"Rice\",\"price\":57.82,\"quantity\":\"10\",\"total\":578.2}]",
      purchaseDate: "2022-05-20",
      sellerAddress1: "ottan kovil, komarapalayam",
      sellerGst: "AZKPC3271C",
      sellerId: "tnalcVjn0E2",
      sellerMobile: "8526868928",
      sellerName: "Chandru",
      total: 2023.7
    }
    ]
  }

  getAllPurchases() {
    this.dbService.dbState().subscribe((res) => {
      if (res) {
        this.dbService.fetchPurchases().subscribe(async (purchases: Purchase[]) => {
          this.purchases = purchases;
        });
      }
    });
  }

  async presentModal(type, purchase) {

    if (type == "edit") {
      this.dbService.purchaseObj = purchase;
      const modal = await this.modalController.create({
        component: PurchaseModalPage,
        cssClass: 'purchase-modal',
        backdropDismiss: false,
        componentProps: {
          'type': type,
          'purchase': purchase
        }
      });
      modal.onDidDismiss().then((modelData) => {
        if (modelData !== null) {
          this.getAllPurchases();
        }
      });
      return await modal.present();
    } else if (type == 'view') {
      const modal = await this.modalController.create({
        component: InvoicePage,
        // cssClass: 'customer-modal',
        backdropDismiss: false,
        componentProps: {
          'type': type,
          'purchase': purchase
        }
      });
      return await modal.present();
    } else {
      const modal = await this.modalController.create({
        component: PurchaseModalPage,
        // cssClass: 'customer-modal',
        backdropDismiss: false,
        componentProps: {
          'type': type,
          'purchase': undefined
        }
      });
      modal.onDidDismiss().then((modelData) => {
        if (modelData !== null) {
          this.getAllPurchases();
        }
      });
      return await modal.present();
    }

  }

  async deletePurchase(event, purchase) {
    if (event) {
      event.stopPropagation();
    }
    this.dbService.deletePurchase(purchase.id).then(
      async (res) => {
        const toast = await this.toast.create({
          message: 'Purchase deleted',
          duration: 2500,
        });
        toast.present();
      },
      (error) => console.error(error)
    );
  }


  back(){
    console.log("Back!");
    
    this.navCtrl.pop();
  }
}
