export class Category {
    id?: string;
    categoryName: string;
    disabled: boolean;
}
