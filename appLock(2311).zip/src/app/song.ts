export class Song {
    id?: string;
  artistName: string;
  songName: string;
}
