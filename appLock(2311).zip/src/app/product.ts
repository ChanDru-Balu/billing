export class Product {
  id?: string;
  categoryName: string;
  productName: string;
  gst: number;
  price: number;
  quantity: number;
}
