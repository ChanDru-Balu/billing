export class Seller {
    id?: string;
    sellerName: string;
    mobile: string;
    gst: string;
    address1: string;
    disabled: boolean;
}
