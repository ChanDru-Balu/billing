import { Injectable } from '@angular/core';
import { SQLiteObject, SQLite } from '@awesome-cordova-plugins/sqlite/ngx';
import { BehaviorSubject, Observable } from 'rxjs';
import { Platform } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { SQLitePorter } from '@awesome-cordova-plugins/sqlite-porter/ngx';
import * as _ from 'lodash'

import { Song } from './song';
import { generateId } from './helper';
import { Category } from './category';
import { Product } from './product';
import { Customer } from './customer';
import { Seller } from './seller';
import { Purchase } from './purchase';
import { PurchaseItem } from './purchase-item';
import { Sales } from './sales';

@Injectable({
  providedIn: 'root'
})
export class DbService {
  private storage: SQLiteObject;

  songsList = new BehaviorSubject([]);
  CategoriesList = new BehaviorSubject([]);
  ProductsList = new BehaviorSubject([]);
  CustomerList = new BehaviorSubject([]);
  SellerList = new BehaviorSubject([]);
  purchaseList = new BehaviorSubject([]);
  salesList = new BehaviorSubject([]);
  purchaseItemList = new BehaviorSubject([]);

  private isDbReady: BehaviorSubject<boolean> = new BehaviorSubject(false);
  purchaseObj: any;
  salesObj: any;

  constructor(
    private platform: Platform,
    private sqlite: SQLite,
    private httpClient: HttpClient,
    private sqlPorter: SQLitePorter
  ) {
    this.platform.ready().then(() => {
      this.sqlite
        .create({
          name: 'song_list_db.db',
          location: 'default',
        })
        .then((db: SQLiteObject) => {
          this.storage = db;
          this.getDummyData();
        });
    });
  }

  dbState() {
    return this.isDbReady.asObservable();
  }

  fetchSongs(): Observable<Song[]> {
    return this.songsList.asObservable();
  }

  fetchCategories(): Observable<Category[]> {
    return this.CategoriesList.asObservable();
  }

  fetchProducts(): Observable<Product[]> {
    return this.ProductsList.asObservable();
  }

  fetchCustomers(): Observable<Customer[]> {
    return this.CustomerList.asObservable();
  }

  fetchSellers(): Observable<Seller[]> {
    return this.SellerList.asObservable();
  }

  fetchPurchases(): Observable<Purchase[]> {
    return this.purchaseList.asObservable();
  }

  fetchSaleses(): Observable<Sales[]> {
    return this.salesList.asObservable();
  }

  // fetchPurchaseItems(): Observable<any[]> {
  //   return this.purchaseItemList.asObservable();
  // }

  getDummyData() {
    this.httpClient
      .get('assets/dumb.sql', { responseType: 'text' })
      .subscribe((data) => {
        this.sqlPorter
          .importSqlToDb(this.storage._objectInstance, data)
          .then(() => {
            this.getAllSongs();
            this.getAllCategories();
            this.getAllProducts();
            this.getAllCustomers();
            this.getAllSellers();
            this.getAllPurchases();
            this.isDbReady.next(true);
          })
          .catch((error) => console.error(error));
      });
  }

  // Songs

  getAllSongs() {
    return this.storage
      .executeSql('SELECT * FROM songtable;', [])
      .then((res) => {
        const songs: Song[] = [];
        if (res.rows.length > 0) {
          for (let i = 0; i < res.rows.length; i++) {
            songs.push({
              id: res.rows.item(i).id,
              artistName: res.rows.item(i).artistName,
              songName: res.rows.item(i).songName,
            });
          }
        }
        this.songsList.next(songs);
      });
  }

  getSong(id: string): Promise<Song> {
    return this.storage.executeSql('', [id]).then((res) => {
      return {
        id: res.rows.item(0).id,
        songName: res.rows.item(0).songName,
        artistName: res.rows.item(0).artistName,
      };
    });
  }

  addSong(song: Song) {
    const data = [generateId(), song.songName, song.artistName];
    return this.storage
      .executeSql(
        'INSERT INTO songtable (id, songName, artistName) VALUES (?, ?, ?);',
        data
      )
      .then(
        () => this.getAllSongs(),
        (error) => console.error(error)
      );
  }

  updateSong(id: string, song: Song) {
    const data = [song.songName, song.artistName];
    return this.storage
      .executeSql(
        `UPDATE songtable SET songName = ?, artistName = ? WHERE id = ${id};`,
        data
      )
      .then(() => this.getAllSongs());
  }

  deleteSong(id: string) {
    return this.storage
      .executeSql('DELETE FROM songtable WHERE id = ?;', [id])
      .then(
        () => this.getAllSongs(),
        (error) => console.error(error)
      );
  }

  deleteAllSongs() {
    return this.storage.executeSql('DELETE FROM songtable;', []).then(
      () => this.getAllSongs(),
      (error) => console.error(error)
    );
  }


  // Purchase

  getAllPurchases() {
    return this.storage
      .executeSql('SELECT * FROM purchasetable;', [])
      .then((res) => {
        const purchases: Purchase[] = [];
        if (res.rows.length > 0) {
          for (let i = 0; i < res.rows.length; i++) {
            purchases.push({
              id: res.rows.item(i).id,
              purchaseDate: res.rows.item(i).purchaseDate,
              invoice: res.rows.item(i).invoice,
              total: res.rows.item(i).total,
              discount: res.rows.item(i).discount,
              grandTotal: res.rows.item(i).grandTotal,
              sellerAddress1: res.rows.item(i).sellerAddress1,
              sellerGst: res.rows.item(i).sellerGst,
              sellerId: res.rows.item(i).sellerId,
              sellerMobile: res.rows.item(i).sellerMobile,
              sellerName: res.rows.item(i).sellerName,
              items: res.rows.item(i).items
            });
          }
        }
        this.purchaseList.next(purchases);

      });
  }

  addPurchase(purchase: Purchase, items: any) {
    const data = [generateId(), purchase.purchaseDate, purchase.invoice, purchase.total, purchase.discount, purchase.grandTotal
      , purchase.sellerAddress1, purchase.sellerGst, purchase.sellerId, purchase.sellerMobile, purchase.sellerName, items];
    return this.storage
      .executeSql(
        `INSERT INTO purchasetable (id, purchaseDate, invoice, total, discount, grandTotal,sellerAddress1,sellerGst,
          sellerId,sellerMobile,sellerName,items ) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
        data
      )
      .then(
        (res) => {  this.getAllPurchases() },
        (error) =>{ console.error(error); 
          if(error.code == 6){
            alert("Invoice Already Exist!");
          };
         }
      );
  }

  updateProductCount(productName: string,count: number){
    alert("Count&ProdName,"+productName+count);
    return this.storage
    .executeSql('UPDATE producttable SET quantity = ? WHERE productName = ?;', [count,productName])
    .then(
      (res) => { 
        alert(JSON.stringify(res))
        return {
          id: res.rows.item(0).id,
          productName: res.rows.item(0).productName,
          quantity: res.rows.item(0).quantity
        };
      },
      (error) => alert(JSON.stringify(error))
    );
  }

  updatePurchase(purchase: Purchase, items: any) {
    return this.storage
      .executeSql(
        `UPDATE purchasetable SET purchaseDate = ?, invoice = ?, total = ?, discount = ?, grandTotal = ?,sellerAddress1 = ?,
        sellerGst  = ?, sellerId = ? ,sellerMobile = ? ,sellerName  = ?,items  = ?
        WHERE id = ?`,
        [purchase.purchaseDate, purchase.invoice, purchase.total, purchase.discount, purchase.grandTotal, purchase.sellerAddress1,
        purchase.sellerGst, purchase.sellerId, purchase.sellerMobile, purchase.sellerName, items, purchase.id
        ]
      )
      .then((data) => { this.getAllPurchases(); })
      .catch((error) => {
        if(error.code == 6){
          alert("Invoice Already Exist!");
        }
        
      })
      ;
  }

  deletePurchase(id: string) {
    return this.storage
      .executeSql('DELETE FROM purchasetable WHERE id = ?;', [id])
      .then(
        () => this.getAllPurchases(),
        (error) => console.error(error)
      );
  }

  // Sales
  getAllSalses() {
    return this.storage
      .executeSql('SELECT * FROM salestable;', [])
      .then((res) => {
        const saleses: Sales[] = [];
        if (res.rows.length > 0) {
          for (let i = 0; i < res.rows.length; i++) {
            saleses.push({
              id: res.rows.item(i).id,
              sellDate: res.rows.item(i).sellDate,
              invoice: res.rows.item(i).invoice,
              total: res.rows.item(i).total,
              discount: res.rows.item(i).discount,
              grandTotal: res.rows.item(i).grandTotal,
              customerAddress1: res.rows.item(i).customerAddress1,
              customerId: res.rows.item(i).customerId,
              customerMobile: res.rows.item(i).customerMobile,
              customerName: res.rows.item(i).customerName,
              items: res.rows.item(i).items
            });
          }
        }
        this.salesList.next(saleses);
      });
  }

  addSales(sales: Sales, items: any) {
    const data = [generateId(), sales.sellDate, sales.invoice, sales.total, sales.discount, sales.grandTotal
      , sales.customerAddress1, sales.customerId, sales.customerMobile, sales.customerName, items];
    return this.storage
      .executeSql(
        `INSERT INTO salestable (id, sellDate, invoice, total, discount, grandTotal,customerAddress1,
          customerId,customerMobile,customerName,items ) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
        data
      )
      .then(
        (res) => { this.getAllSalses() },
        (error) => {console.error(error);
          if(error.code == 6){
            alert("Invoice Already Exist!");
          };
        }
      );
  }

  updateSales(sales: Sales, items: any) {
    return this.storage
      .executeSql(
        `UPDATE salestable SET sellDate = ?, invoice = ?, total = ?, discount = ?, grandTotal = ?,customerAddress1 = ?,
         sellerId = ? ,sellerMobile = ? ,sellerName  = ?,items  = ?
        WHERE id = ?`,
        [sales.sellDate, sales.invoice, sales.total, sales.discount, sales.grandTotal, sales.customerAddress1,
           sales.customerId, sales.customerMobile, sales.customerName, items, sales.id
        ]
      )
      .then((data) => { this.getAllSalses(); })
      .catch((error) => {
        if(error.code == 6){
          alert("Invoice Already Exist!");
        };
      })
      ;
  }

  deleteSales(id: string) {
    return this.storage
      .executeSql('DELETE FROM salestable WHERE id = ?;', [id])
      .then(
        () => this.getAllSalses(),
        (error) => console.error(error)
      );
  }

  // Seller

  getAllSellers() {
    return this.storage
      .executeSql('SELECT * FROM sellertable;', [])
      .then((res) => {
        const sellers: Seller[] = [];
        if (res.rows.length > 0) {
          for (let i = 0; i < res.rows.length; i++) {
            sellers.push({
              id: res.rows.item(i).id,
              sellerName: res.rows.item(i).sellerName,
              mobile: res.rows.item(i).mobile,
              gst: res.rows.item(i).gst,
              address1: res.rows.item(i).address1,
              disabled: true
            });
          }
        }
        this.SellerList.next(sellers);
      });
  }

  addSeller(seller: Seller) {
    const data = [generateId(), seller.sellerName, seller.mobile, seller.gst, seller.address1];
    return this.storage
      .executeSql(
        'INSERT INTO sellertable (id, sellerName, mobile, gst, address1 ) VALUES (?, ?, ? , ?, ?);',
        data
      )
      .then(
        (res) => {
          this.getAllSellers(); ;
        },
        (error) => {console.error({ error });
      
        if(error.code == 6){
          alert("Sellere Name Already Exist!");
        };}
      );
  }

  updateSeller(seller: Seller) {
    return this.storage
      .executeSql(
        `UPDATE sellertable SET sellerName = ?, mobile = ? , gst = ? , address1 = ? WHERE id = ?`,
        [seller.sellerName, seller.mobile, seller.gst, seller.address1, seller.id]
      )
      .then((data) => { this.getAllSellers(); })
      .catch((error) => {
        if(error.code == 6){
          alert("Seller Name Already Exist!");
        };
      })
      ;
  }

  deleteSeller(id: string) {
    return this.storage
      .executeSql('DELETE FROM sellertable WHERE id = ?;', [id])
      .then(
        () => this.getAllSellers(),
        (error) => console.error(error)
      );
  }

  // Customer

  getAllCustomers() {
    return this.storage
      .executeSql('SELECT * FROM customertable;', [])
      .then((res) => {
        const customers: Customer[] = [];
        if (res.rows.length > 0) {
          for (let i = 0; i < res.rows.length; i++) {
            customers.push({
              id: res.rows.item(i).id,
              customerName: res.rows.item(i).customerName,
              mobile: res.rows.item(i).mobile,
              address1: res.rows.item(i).address1,
              disabled: true
            });
          }
        }
        this.CustomerList.next(customers);
      });
  }

  getCustomer(id: string): Promise<Song> {
    return this.storage.executeSql('', [id]).then((res) => {
      return {
        id: res.rows.item(0).id,
        songName: res.rows.item(0).songName,
        artistName: res.rows.item(0).artistName,
      };
    });
  }

  addCustomer(customer: Customer) {
    const data = [generateId(), customer.customerName, customer.mobile, customer.address1];
    return this.storage
      .executeSql(
        'INSERT INTO customertable (id, customerName, mobile, address1 ) VALUES (?, ?, ? , ?);',
        data
      )
      .then(
        (res) => {
          this.getAllCustomers(); ;
        },
        (error) => {console.error({ error });
        if(error.code == 6){
          alert("Customer Name Already Exist!");
        };}
      );
  }

  updateCustomer(customer: Customer) {

    return this.storage
      .executeSql(
        `UPDATE customertable SET customerName = ?, mobile = ? , address1 = ? WHERE id = ?`,
        [customer.customerName, customer.mobile, customer.address1, customer.id]
      )
      .then((data) => { this.getAllCustomers(); })
      .catch((error) => {
        if(error.code == 6){
          alert("Customer Name Already Exist!");
        };
      })
      ;
  }

  deleteCustomer(id: string) {
    return this.storage
      .executeSql('DELETE FROM customertable WHERE id = ?;', [id])
      .then(
        () => this.getAllCustomers(),
        (error) => console.error(error)
      );
  }


  // Categories

  getAllCategories() {
    return this.storage
      .executeSql('SELECT * FROM categorytable;', [])
      .then((res) => {
        const categories: Category[] = [];
        if (res.rows.length > 0) {
          for (let i = 0; i < res.rows.length; i++) {
            categories.push({
              id: res.rows.item(i).id,
              categoryName: res.rows.item(i).categoryName,
              disabled: false
            });
          }
        }
        this.CategoriesList.next(categories);
      });
  }

  getCategory(id: string): Promise<Category> {
    return this.storage.executeSql('', [id]).then((res) => {
      return {
        id: res.rows.item(0).id,
        categoryName: res.rows.item(0).categoryName,
        disabled: false
      };
    });
  }

  addCategory(category: Category) {
    const data = [generateId(), category.categoryName];
    return this.storage
      .executeSql(
        'INSERT INTO categorytable (id, categoryName) VALUES (?, ?);',
        data
      )
      .then(
        () => this.getAllCategories(),
        (error) => {console.error(error);
        if(error.code == 6){
          alert("Category Name Already Exist!");
        }
        }
      );
  }

  updateCategory(id: string, category: string) {

    const data = [category];
    return this.storage
      .executeSql(
        'UPDATE categorytable SET categoryName = ? WHERE id = ?;',
        [category, id]
      )
      .then(() => this.getAllCategories()).catch((error) => {
        if(error.code == 6){
          alert("Category Name Already Exist!");
        }
      });
  }

  deleteCategroy(id: string) {
    return this.storage
      .executeSql('DELETE FROM categorytable WHERE id = ?;', [id])
      .then(
        () => this.getAllCategories(),
        (error) => console.error(error)
      );
  }

  deleteAllCategories() {
    return this.storage.executeSql('DELETE FROM categorytable;', []).then(
      () => this.getAllCategories(),
      (error) => console.error(error)
    );
  }



  // Products

  getAllProducts() {
    return this.storage
      .executeSql('SELECT * FROM producttable;', [])
      .then((res) => {
        const products: Product[] = [];
        if (res.rows.length > 0) {
          for (let i = 0; i < res.rows.length; i++) {
            products.push({
              id: res.rows.item(i).id,
              categoryName: res.rows.item(i).categoryName,
              productName: res.rows.item(i).productName,
              gst: res.rows.item(i).gst,
              price: res.rows.item(i).price,
              quantity: res.rows.item(i).quantity
            });
          }
        }
        this.ProductsList.next(products);
      });
  }

  getProduct(id: string): Promise<Category> {
    return this.storage.executeSql('', [id]).then((res) => {
      return {
        id: res.rows.item(0).id,
        categoryName: res.rows.item(0).categoryName,
        disabled: false
      };
    });
  }

  getProductCount(productName: string){
    return this.storage
    .executeSql('SELECT * FROM producttable WHERE productName = ?;', [productName])
    .then(
      (res) => { 
        return {
          id: res.rows.item(0).id,
          productName: res.rows.item(0).productName,
          quantity: res.rows.item(0).quantity
        };
      },
      (error) => console.error(error)
    );
  }

  

  addProduct(product: Product) {
    const data = [generateId(), product.categoryName, product.productName, product.gst, product.price, product.quantity];
    return this.storage
      .executeSql(
        'INSERT INTO producttable (id, categoryName , productName , gst , price, quantity) VALUES (?, ?, ?, ?, ? ,?);',
        data
      )
      .then(
        () => this.getAllProducts(),
        (error) => {console.error(error);
          if(error.code == 6){
            alert("Product Name Already Exist!");
          };}
      );
  }

  updateProduct(product: any) {

    // const data = [category];
    return this.storage
      .executeSql(
        'UPDATE producttable SET categoryName = ? , productName = ? , gst = ? , price = ? WHERE id = ?;',
        [product.category, product.name, product.gst, product.price, product.id]
      )
      .then((res) => {
        this.getAllProducts();
      }).catch((error) => {
        if(error.code == 6){
          alert("Product Name Already Exist!");
        };
      });
  }

  deleteProduct(id: string) {
    return this.storage
      .executeSql('DELETE FROM producttable WHERE id = ?;', [id])
      .then(
        () => this.getAllProducts(),
        (error) => console.error(error)
      );
  }

  deleteAllProducts() {
    return this.storage.executeSql('DELETE FROM categorytable;', []).then(
      () => this.getAllProducts(),
      (error) => console.error(error)
    );
  }




}
