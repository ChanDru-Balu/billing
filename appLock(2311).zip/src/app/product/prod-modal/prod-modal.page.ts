import { Component, Input, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-prod-modal',
  templateUrl: './prod-modal.page.html',
  styleUrls: ['./prod-modal.page.scss'],
})
export class ProdModalPage implements OnInit {

  @Input() type: string;
  @Input() categories: any;
  @Input() product: any;
  
  category: any ;
  name: any;
  gst: any;
  price: any;

  submitValue: boolean = false;
  constructor(
    private modalController: ModalController
  ) { 
    // if(this.type == "edit"){
    //   this.category = this.product.categoryName;
    //   this.name = this.product.productName;
    //   this.gst = this.product.gst;
    //   this.price = this.product.price;
    // }
  }

  ngOnInit() {
    if(this.type == "edit"){
      this.category = this.product.categoryName;
      this.name = this.product.productName;
      this.gst = this.product.gst;
      this.price = this.product.price;
    }
  }

  dismiss(){
    this.modalController.dismiss();
  }

  submit(){
    if(this.type == 'edit'){
      this.modalController.dismiss({
        category: this.category,
        name: this.name,
        gst: this.gst,
        price: this.price,
        id: this.product.id
      });
    } else {
      this.modalController.dismiss({
        category: this.category,
        name: this.name,
        gst: this.gst,
        price: this.price
      });

    }
   
  }

  categoryInput(variable){
    if(
      this.category == null || this.category == undefined || this.category == '' ||
      this.name == null || this.name == undefined || this.name == '' ||
      this.price == null || this.price == undefined || this.price == '' ||
      this.gst == null || this.gst == undefined || this.gst == ''
    ){
      this.submitValue = true;
    }else{
      this.submitValue = false;
    }
  }

}
