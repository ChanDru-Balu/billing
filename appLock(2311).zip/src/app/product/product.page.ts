import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
} from '@angular/forms';
import { DbService } from '../db.service';
import {
  ModalController,
  NavController,
  ToastController,
} from '@ionic/angular';
import * as _ from 'lodash';
import { Product } from '../product';
import { Category } from '../category';
import { ProdModalPage } from './prod-modal/prod-modal.page';
import { disableDebugTools } from '@angular/platform-browser';

@Component({
  selector: 'app-product',
  templateUrl: './product.page.html',
  styleUrls: ['./product.page.scss'],
})
export class ProductPage implements OnInit {
  productFormGroup: FormGroup;
  productFormData: any;
  products: any = [];
  categories: Category[];
  category: any;
  test = {
    categoryName: 'category one',
    gst: 10,
    id: 'Xq2QKI4lmaY',
    price: 100,
    productName: 'product one',
    quantity: 0,
  };

  constructor(
    private formBuilder: FormBuilder,
    private navController: NavController,
    private dbService: DbService,
    private toast: ToastController,
    private modalController: ModalController
  ) {}

  ngOnInit() {
    this.productFormData = {
      inputs: [
        { label: 'Product Name', formControlName: 'product', type: 'text' },
        { label: 'GST', formControlName: 'gst', type: 'number' },
        { label: 'Price', formControlName: 'price', type: 'number' },
      ],
    };

    this.generateEmptyForm();
    this.dbService.dbState().subscribe((res) => {
      if (res) {
        this.dbService
          .fetchProducts()
          .subscribe(async (products: Product[]) => {
            this.products = products;
            console.log({ products });
            for (let i = 0; i < this.products.length; i++) {
              this.products[i]['disabled'] = true;
            }
            console.log(this.products);
            this.dbService
              .fetchCategories()
              .subscribe(async (categories: Category[]) => {
                this.categories = categories;
              });
          });
      } else {
        this.products = [
          {
            categoryName: 'category one',
            gst: 10,
            id: 'Xq2QKI4lmaY',
            price: 100,
            productName: 'product one',
            quantity: 0,
          },
        ];

        this.categories = [  
          { categoryName: "category one",  id: "5NAsDXhCsdi" , disabled: true },
          { categoryName: "category two",  id: "5NAsDXhCsde" , disabled: true },
          { categoryName: "category three",id: "5NAsDXhCssw" , disabled: true },
          { categoryName: "category four", id: "5NAsDXhCsju" , disabled: true }
        ]

        for (let i = 0; i < this.products.length; i++) {
          this.products[i]['disabled'] = true;
        }
        console.log(this.products);
      }
    });
  }

  generateEmptyForm() {
    this.productFormGroup = this.formBuilder.group({});
    _.forEach(this.productFormData.inputs, (input: any) => {
      this.productFormGroup.addControl(
        input.formControlName,
        new FormControl('', Validators.required)
      );
    });
  }

  addProduct(product) {
    this.dbService
      .addProduct({
        categoryName: product.category,
        productName: product.name,
        gst: product.gst,
        price: product.price,
        quantity: 0,
      })
      .then(
        (res) => {
          this.productFormGroup.reset();
        },
        async () => {
          const toast = await this.toast.create({
            duration: 2500,
            message: 'Failed to add Product',
          });
          toast.present();
        }
      );
  }

  deleteProduct(e, id: string) {
    if (e) {
      e.stopPropagation();
    }
    this.dbService.deleteProduct(id).then(
      async (res) => {
        const toast = await this.toast.create({
          message: 'Product deleted',
          duration: 2500,
        });
        toast.present();
      },
      (error) => console.error(error)
    );
  }

  editProduct(product: any) {
    alert(JSON.stringify(product))
    this.dbService.updateProduct(product).then(
      (res) => {
        alert(res);
      },
      async () => {
        const toast = await this.toast.create({
          duration: 2500,
          message: 'Failed to Edit Category',
        });
        toast.present();
      }
    );
  }

  clearAllProducts(e) {
    this.dbService.deleteAllProducts().then(
      () => {},
      async () => {
        const toast = await this.toast.create({
          message: 'Failed to Delete All',
          duration: 2500,
        });
        toast.present();
      }
    );
  }

  async presentModal(type, product: any) {
    if (type == 'edit') {
      const modal = await this.modalController.create({
        component: ProdModalPage,
        cssClass: 'prod-modal',
        backdropDismiss: false,
        componentProps: {
          type: type,
          categories: this.categories,
          product: product,
        },
      });
      modal.onDidDismiss().then((modelData) => {
        if (modelData !== null) {
          this.editProduct(modelData.data);
        }
      });
      return await modal.present();
    } else {
      const modal = await this.modalController.create({
        component: ProdModalPage,
        cssClass: 'prod-modal',
        backdropDismiss: false,
        componentProps: {
          type: type,
          categories: this.categories,
          product: undefined,
        },
      });
      modal.onDidDismiss().then((modelData) => {
        if (modelData !== null) {
          this.addProduct(modelData.data);
        }
      });
      return await modal.present();
    }
  }

  back() {
    this.navController.pop();
  }

  changeProduct(product) {
    console.log(product.disabled);
    if (product.disabled) {
      for (let i = 0; i < this.products.length; i++) {
        if (this.products[i].id == product.id) {
          product.disabled = false;
        } else {
          product.disabled = true;
        }
      }
    } else {
      product.disabled = true
      let newProduct = JSON.parse(JSON.stringify(product))
      console.log({newProduct})
      // alert(JSON.stringify(newProduct))
      delete newProduct['disabled'];

      this.editProduct(newProduct);

    }
  }

  onChangeCateory(ev:any, i){
    console.log({ev},i)
  }
}
