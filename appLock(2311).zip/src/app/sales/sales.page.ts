import { Component, OnInit } from '@angular/core';
import { ModalController, NavController, ToastController } from '@ionic/angular';
import { DbService } from '../db.service';
import { Sales } from '../sales';
import { Customer } from '../customer';
import { PurchaseModalPage } from '../purchase/purchase-modal/purchase-modal.page';
import { InvoicePage } from '../purchase/invoice/invoice.page';
import { SalesModalPage } from './sales-modal/sales-modal.page';
import { SalesInvoicePage } from './sales-invoice/sales-invoice.page';
// import { InvoicePage } from './invoice/invoice.page';
// import { PurchaseModalPage } from './purchase-modal/purchase-modal.page';

@Component({
  selector: 'app-sales',
  templateUrl: './sales.page.html',
  styleUrls: ['./sales.page.scss'],
})
export class SalesPage implements OnInit {

  customers: Customer[];
  seller: any;
  invoice: any;
  saleses: Sales[];

  constructor(
    private modalController: ModalController,
    private dbService: DbService,
    private toast: ToastController,
    private navController: NavController
  ) { }

  ngOnInit() {
    this.getAllSales();
    this.customers = [
      {
        id: '23213dsda3321',
        customerName: 'chandru',
        mobile: 8526868928,
        address1: 'address1',
        disabled: true
      },
      {
        id: '23213dsda3322',
        customerName: 'chan',
        mobile: 9385891608,
        address1: 'address1',
        disabled: true

      }
    ]

    this.saleses = [
     {
      discount: 445.5,
      grandTotal: 1000,
      id: "1Gu2cicDK82",
      invoice: "0001",
      items: "[{\"productName\":\"Rice\",\"price\":57.82,\"quantity\":\"25\",\"total\":1445.5},{\"productName\":\"Rice\",\"price\":57.82,\"quantity\":\"10\",\"total\":578.2}]",
      sellDate: "2022-05-20",
      customerAddress1: "ottan kovil, komarapalayam",
      customerId: "tnalcVjn0E2",
      customerMobile: "8526868928",
      customerName: "Chandru",
      total: 2023.7
    }
    ]
  }

  getAllSales() {
    this.dbService.dbState().subscribe((res) => {
      if (res) {
        this.dbService.fetchSaleses().subscribe(async (saleses: Sales[]) => {
          this.saleses = saleses;
        });
      }
    });
  }

  async presentModal(type, sales) {

    if (type == "edit") {
      this.dbService.salesObj = sales;
      const modal = await this.modalController.create({
        component: SalesModalPage,
        // cssClass: 'customer-modal',
        backdropDismiss: false,
        componentProps: {
          'type': type,
          'sales': sales
        }
      });
      modal.onDidDismiss().then((modelData) => {
        if (modelData !== null) {
          this.getAllSales();
        }
      });
      return await modal.present();
    } else if (type == 'view') {

      const modal = await this.modalController.create({
        component: SalesInvoicePage,
        // cssClass: 'customer-modal',
        backdropDismiss: false,
        componentProps: {
          'type': type,
          'sales': sales
        }
      });
      return await modal.present();
    } else {
      const modal = await this.modalController.create({
        component: SalesModalPage,
        // cssClass: 'customer-modal',
        backdropDismiss: false,
        componentProps: {
          'type': type,
          'sales': undefined
        }
      });
      modal.onDidDismiss().then((modelData) => {
        if (modelData !== null) {
          this.getAllSales();
        }
      });
      return await modal.present();
    }

  }

  async deleteSales(event, sales) {
    if (event) {
      event.stopPropagation();
    }
    this.dbService.deleteSales(sales.id).then(
      async (res) => {
        const toast = await this.toast.create({
          message: 'Purchase deleted',
          duration: 2500,
        });
        toast.present();
      },
      (error) => console.error(error)
    );
  }

  back(){
    this.navController.pop();
  }

}
