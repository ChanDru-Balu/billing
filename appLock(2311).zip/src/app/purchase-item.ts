export class PurchaseItem {
    id? :string;
    invoice :string;
    price :number;
    productName :string;
    quantity :number;
    total :number;
}

