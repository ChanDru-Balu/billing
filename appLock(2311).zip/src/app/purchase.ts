export class Purchase {
    id?: string;
    purchaseDate: string;
    invoice: string;
    total: number;
    discount: number;
    grandTotal: number;
    sellerAddress1: string;
    sellerGst: string;
    sellerId:string;
    sellerMobile: string;
    sellerName: string;
    items: string;
}


