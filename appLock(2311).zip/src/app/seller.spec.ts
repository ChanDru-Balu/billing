import { Seller } from './seller';

describe('Seller', () => {
  it('should create an instance', () => {
    expect(new Seller()).toBeTruthy();
  });
});
